package com.ideabox.bloodbank;

/**
 * Created by Tilak on 05/06/16.
 */
public class DonerData {

    public int id;
    public String full_name;
    public String email;
    public String phone;
    public String addr;
    public String bloodgrp;
    public String city;
    public String area;

}
