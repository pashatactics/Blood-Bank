# BloodBank
This app help users to find doner of particular Blood Group and it could filter results based on location. The doners can register themselves and provide their contact details.<br>

BloodBank Android App. Below is the screenshot of the app.<br><br>
![Screenshot](http://telegra.ph/file/22e2a0db3c774ce1dcc1a.jpg)
